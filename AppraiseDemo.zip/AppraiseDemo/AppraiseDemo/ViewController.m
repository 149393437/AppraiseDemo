//
//  ViewController.m
//  AppraiseDemo
//
//  Created by 张诚 on 14/12/2.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "ViewController.h"
#import "iRate.h"
@interface ViewController ()<iRateDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton*button=[UIButton buttonWithType:UIButtonTypeCustom];
    button.frame=CGRectMake(100, 100, 100, 100);
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button setTitle:@"评分" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(buttonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)buttonClick{
    
    [[iRate sharedInstance]showAlertWithStoreID:897504228 BundleID:@"com.zc.weichat" MessageTitle:@"小苍冰天雪地360°跪求一个好评" Message:@"小苍如此辛苦的写应用，恳求大人您可怜可怜我，给我一个好评吧，么么哒😊" rateTitle:@"这就去给小苍鼓励" waitTitle:@"等待下次提示" cancelTitle:@"残忍的拒绝" Block:^(int x) {
        
        switch (x) {
            case 0:
                NSLog(@"拒绝评价");
                break;
            case 1:
                NSLog(@"评价");
                break;
            case 2:
                NSLog(@"下次评价");
                break;
            default:
                break;
        }
    }];
  
    
    iRate*rate= [iRate sharedInstance];
    //弹出警告框的文字说明，如果不设置也可以是默认的
    rate.messageTitle=@"小苍冰天雪地360°跪求一个好评";
    rate.message=@"小苍如此辛苦的写应用，恳求大人您可怜可怜我，给我一个好评吧，么么哒😊";
    rate.rateButtonLabel=@"这就去给小苍鼓励";
    rate.remindButtonLabel=@"等待下次提示";
    rate.cancelButtonLabel=@"残忍的拒绝";
   
    //设置代理
    rate.delegate=self;
    


}
- (void)iRateCouldNotConnectToAppStore:(NSError *)error{

}
//评价
- (void)iRateUserDidAttemptToRateApp{
    NSLog(@"评价");
}
//拒绝评价
- (void)iRateUserDidDeclineToRateApp{
    NSLog(@"拒绝评价");
}
//下次评价
- (void)iRateUserDidRequestReminderToRateApp{
    NSLog(@"下次评价");
    //点击下次评价后，不会在本次启动中再次运行
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
